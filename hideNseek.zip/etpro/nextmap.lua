Version = "1.0"
Modname = "Nextmap Announce"

-------------------------------------------------

function et_InitGame(levelTime,randomSeed,restart)
	et.G_Print("[Nextmap] Version:"..Version.." Loaded\n")
   	et.RegisterModname(Modname .. " " .. Version)
end

-------------------------------------------------

samplerate = 400000  --300000
map1 = "supply"
map2 = "oasis"
map3 = "goldrush"
map4 = "radar"
map5 = "tc_base"
map6 = "et_beach"
map7 = "frostbite"
map8 = "sp_delivery_te"
map9 = "adlernest"
map10 = "bremen_b2"
map11 = "braundorf_b4"
map12 = "et_ice"
map13 = "goldrush-ga"
map14 = "railgun"
map15 = "dubrovnik_final"
map16 = "sw_battery"
map17 = "et_village"
map18 = "fueldump"

-------------------------------------------------

function et_RunFrame( levelTime )
	if math.mod(levelTime, samplerate) ~= 0 then return end
       mapname = et.trap_Cvar_Get( "mapname" )         
	 if mapname == map1 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map2.."\n\"" )
	 elseif mapname == map2 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map3.."\n\"" )
	 elseif mapname == map3 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map4.."\n\"" )
	 elseif mapname == map4 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map5.."\n\"" )
	 elseif mapname == map5 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map6.."\n\"" )
	 elseif mapname == map6 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map7.."\n\"" )
	 elseif mapname == map7 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map8.."\n\"" )
	 elseif mapname == map8 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map9.."\n\"" ) 
	 elseif mapname == map9 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map10.."\n\"" ) 
	 elseif mapname == map10 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map11.."\n\"" ) 
	 elseif mapname == map11 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map12.."\n\"" ) 
	 elseif mapname == map12 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map13.."\n\"" ) 
	 elseif mapname == map13 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map14.."\n\"" ) 
	 elseif mapname == map14 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map15.."\n\"" )     
	 elseif mapname == map15 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map16.."\n\"" )  
	 elseif mapname == map16 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map17.."\n\"" )  
	 elseif mapname == map17 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map18.."\n\"" )       
	 elseif mapname == map18 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map1.."\n\"" )  
         end
       end

  
function et_ClientCommand(client, command)
	local 	mapname = et.trap_Cvar_Get( "mapname" ) 
  if string.lower(command) == "callvote" then
	if et.trap_Argv(1) == "nextmap" then
	 if mapname == map1 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map2.."\n\"" )
	 elseif mapname == map2 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map3.."\n\"" )
	 elseif mapname == map3 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map4.."\n\"" )
	 elseif mapname == map4 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map5.."\n\"" )
	 elseif mapname == map5 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map6.."\n\"" )
	 elseif mapname == map6 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map7.."\n\"" )
	 elseif mapname == map7 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map8.."\n\"" )
	 elseif mapname == map8 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map9.."\n\"" ) 
	 elseif mapname == map9 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map10.."\n\"" ) 
	 elseif mapname == map10 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map11.."\n\"" ) 
	 elseif mapname == map11 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map12.."\n\"" ) 
	 elseif mapname == map12 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map13.."\n\"" ) 
	 elseif mapname == map13 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map14.."\n\"" ) 
	 elseif mapname == map14 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map15.."\n\"" )     
	 elseif mapname == map15 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map16.."\n\"" )  
	 elseif mapname == map16 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map17.."\n\"" )  
	 elseif mapname == map17 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map18.."\n\"" )     
	 elseif mapname == map18 then
	         et.trap_SendServerCommand(-1, "chat \"^1Nextmap: ^3"..map1.."\n\"" )     
        	    end	
     	        end
	    end
	end
