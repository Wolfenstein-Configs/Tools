	Readme File:
--------WOLFENSTEIN---------
    ==ENEMY=TERRITORY==

Made by Micha!

Hide&Seek Pack for etpro

Have fun with this simple pack!
You need the hs.lua to get the basic h&s settings.

Visit eLemenT'HideNSeek
188.40.49.145:27972
for better support/settings
#h&s.et (@quakenet)

Updated July 2009
Copyright: You aren't allowed to change the configs and/or the luas

Check out my other configs too (example: baserace competetion settings or luger only)
www.gs2175.fastdl.de