package etstatistics;

public class WeaponStatistic {
	public String weaponName;
	public int shots, hits, kills, deaths, headshots;
	//Calculated data
	public double acc, headAcc;
}