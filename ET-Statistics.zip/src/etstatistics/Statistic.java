package etstatistics;

import java.util.ArrayList;

//Read data of one (and only one) statistic file
public class Statistic {
	public String map;
	public String playerName;
	public int rounds;

	public ArrayList<WeaponStatistic> weaponStats =
		new ArrayList<WeaponStatistic>();

	public int damageGiven, damageReceived;
	public int teamDamageGiven, teamDamageReceived;
	public int gibs;

	public String rank;
	public int experience;

	//Calculated data
	public int kills, deaths;
	public double eff;
}