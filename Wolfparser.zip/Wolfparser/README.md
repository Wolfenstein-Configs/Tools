Put Wolfparser in the folder where your .cfg files are and sort messy config files in alphabetical order
