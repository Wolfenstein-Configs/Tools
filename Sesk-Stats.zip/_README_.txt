ET Stats Script 2.0 by Sesk
===========================


requires: - Java Runtime Environment (JRE) 1.4.2 or later - http://www.java.com
          - Windows (Only Win XP tested at the moment, should work on others)


Description:
------------
After a war, I used to make stats for my team and me. But each player has his beloved type of stats...
Dealing with that is time consumed, that's why I made a little script in order to do this automatically.

This script generates 3 differents types of stats for the game Enemy Territory : StatWhore, GravyStats & TeamStats.
You can make your stats by using the 3 differents models, or only make it with your beloved one.



Changelog:
----------
- 15/01/2007 - v2.0 : Modularity - You can now make the stats independently
                      FTP support - You can upload your stats to your ftp with the same script

- 12/01/2007 - v1.0 : Started from scratch, the script generates 3 different stats


Usage:
------
Extract "Sesk-Stats-2_0.rar" in the folder you want, it will create a "Sesk-Stats" directory.
In this directory, you have :
- "Progs" directory : The place where are the stats analyzer, gravystats.jar, StatWhore.jar & teamstat.exe
- "Stats" directory : The place where stats will be generated
- "Add-Ons" directory : The place where are the scripts for FTP functionality
- "_Sesk-Stats_.bat" : General script
- "Sesk-Stats_GravyStats.bat" : Script for GravyStats
- "Sesk-Stats_StatWhore.bat" : Script for StatWhore
- "Sesk-Stats_TeamStats.bat" : Script for TeamStats
- "etconsole.log" : Random etconsole.log found on the web

* Before the game *
Check that ET cvar 'logfile' is "2" to enable console logging.
Check that your games is in english : cl_language "0"
Check that cg_drawNotifyText and cg_textNotify are "1" in order to have right log format.
Check that g_logSync "0", and g_log "" ; I don't know if it's really necessary, but if you have any problems, try it.

=> Sum up :
seta cg_drawNotifyText "1" 
seta cg_textNotify "1" 
seta g_logSync "0" 
seta g_log "" 
seta logfile "2"

* After the game * 
Copy your "etconsole.log" (should be in "C:\Program Files\Enemy Territory\etpro\") in the "Sesk-Stats" directory
Double-click on the "_Sesk-Stats_.bat" file.
Close the 2 java pop-ups when their parsing is done (statwhore, and gravystats)
Files will be created inside subdirectory "Stats".

You can either chose only 1 stat's model, by executing "Sesk-Stats_GravyStats.bat", "Sesk-Stats_StatWhore.bat" or "Sesk-Stats_TeamStats.bat" 
instead of "_Sesk-Stats_.bat"



FTP:
----
In the folder "Add-ons", there are 4 directories :
- "_Sesk-Stats_+_FTP_" : In this folder, there are the scripts for making and uploading the 3 differents stats
- "_Sesk-Stats_GravyStats_FTP_" : In this folder, there are the scripts for making and uploading stats from GravyStats
- "_Sesk-Stats_StatWhore_FTP_" : In this folder, there are the scripts for making and uploading stats from StatWhore
- "_Sesk-Stats_TeamStats_FTP_" : In this folder, there are the scripts for making and uploading stats from TeamStats

In the 3 first folders, there are 2 subdirectories, "Full" & "Light", depending if you want to fully upload your files, or only the ".html" files.
For normal utilisation, only light version is used, as a matter of fact the full version is only needed the 1st time in order to upload the folders for pix & javascripts.
TeamStats doesn't use pix or javascript, that's why there is only a light version.

In order to use the FTP feature :
- copy the contents of the directory you have chosen, and paste it into the main directory ("./Sesk-Stats/")
- Open with a text editor the "FTP_***" files (.bat & .txt)
- "FTP_***.bat" : replace "FTP_hostname.com" with your ftp hostname : FTP -i -s:FTP_***.txt FTP_hostname.com
- "FTP_***.bat" : replace "http://www.myWebSite.com/stats/" with the path to the stats folder on your website : START "C:\Program Files\Internet Explorer\IEXPLORE.EXE" http://www.myWebSite.com/stats/
- "FTP_***.txt" : replace "login" with your ftp login
- "FTP_***.txt" : replace "password" with your ftp password

Then, you can execute the "_Sesk-Stats_***_FTP_****_.bat"


If you want to upload the stats to your website without using the scripts, 
don't forget to upload the directories "css", "images", "include" & "js", or your stats will be ugly.


Note that you can delete the folder "Add-ons" if you don't want to use FTP functionality.



Warning:
--------
Do not remove the "Stats/include" directory, the script won't recreate it !
If you did ... :
- copy/paste the "Progs/gravystats.jar" file in the "Sesk-Stats" main directory
- double-click on "gravystats.jar", it will generate a "gravystats" directory
- copy/paste the "gravystats/include" directory in the "Stats" directory
- delete the "gravystats.jar" file from the "Sesk-Stats" main directory



What can make stats differents ?:
---------------------------------
There could be small differences between kills, deaths, dammages ... 
It's NORMAL ! Indeed, the programs don't use same parsers, and calculate stats in different way.

If you fully understand what is in the text of the "etconsole.log", and if you want to have the most real stats, 
you should edit "etconsole.log" with a text editor (i.e. notepad ), and try the following in order to fix some parsing problems :

* PAUSE *
Pause often f*cked the stats, especially dammage side, even if it was during warmup. 
=> Find and delete the lines (Axis example):
=>
=> [skipnotify]^3Match is ^1PAUSED^3!
=> ^7[^1Axis^7^7: - 1 Timeouts Remaining]
=> [skipnotify]*** ^3INFO: ^5^3Match is ^1PAUSED^3! (^1Axis^7^3)
=> 
(keep the blahblah during the pause if you want)
=> 
=> [skipnotify]
=> ^3Match is ^5UNPAUSED^3 ... resuming in 10 seconds!
=> 
=> [skipnotify]^1FIGHT!


* Restart map/round *
=> Find the line "[skipnotify]^1FIGHT!" that match the begin of the round before the restart
=> Find the line "[skipnotify]^1FIGHT!" that match the begin of the round after the restart
=> Delete the lines between this, and keep only 1 of the 2 "[skipnotify]^1FIGHT!"
=>
=> For more precision, do it with the "[skipnotify]etpro: Server version" lines instead of the "FIGHT!" ones.


This should fix most of parsing problems.



Credits:
--------
- gravystats v0.13 : http://www.gameitis.com/phpBB/viewtopic.php?t=610
- statwhore v1.1.9 : http://homepages.paradise.net.nz/kumachan/StatWhore/
- teamstats v1.06 : http://frangen.sourceforge.net/etstat.html



For any help, support or feedback, get me on :
- IRC : #sesk
- www.crossfire.nu : seskapil  (http://www.crossfire.nu/?x=user&mode=view&id=6214)
- www.enemyterritory.fr : Sesk@pil  (http://www.enemyterritory.fr/forums/index.php?showuser=11314)