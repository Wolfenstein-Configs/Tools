//  gravy.js
//  current for version 0.13
//  contents last updated with version 0.11

var numGames;

function switch_kd(which) {
	var wk = document.getElementById("weapon_kills");
	var wk2 = document.getElementById("weapon_kills2");
	var wk3 = document.getElementById("weapon_kills3");
	var wk4 = document.getElementById("weapon_kills4");
	var wd = document.getElementById("weapon_deaths");
	var wd2 = document.getElementById("weapon_deaths2");
	var wd3 = document.getElementById("weapon_deaths3");
	var wd4 = document.getElementById("weapon_deaths4");
	if (which == "kills") {
		wk.style.display = "table-header-group";
		wd.style.display = "none";
		wk2.style.display = "table-header-group";
		wd2.style.display = "none";
		wk3.style.display = "table-header-group";
		wd3.style.display = "none";
		wk4.style.display = "table-header-group";
		wd4.style.display = "none";
	}
	else if (which == "deaths") {
		wd.style.display = "table-header-group";
		wk.style.display = "none";
		wd2.style.display = "table-header-group";
		wk2.style.display = "none";
		wd3.style.display = "table-header-group";
		wk3.style.display = "none";
		wd4.style.display = "table-header-group";
		wk4.style.display = "none";
	}
}

var current_type = "simple";
var current_scope = "global";

function summary_scope(which) {

	current_scope = which;
	
	var global = document.getElementById("global");
	var games = new Array();
	var count;
	
	for (count=0; count < numGames; count++) {
		games[count] = document.getElementById("game"+(count+1));
	}
	
	//hide all
	global.style.display = "none";
	for (count = 0; count < numGames; count++) {
		if (games[count] != null) {
		games[count].style.display = "none";
		}
	}
	//display the right one
	document.getElementById(which).style.display = "block";
	
	
	//Now change the classname of the summary element
	//so we know which one is being displayed
	var global_summary = document.getElementById("summ_global");
	var games_summary = new Array();
	
	for (count=0; count < numGames; count++) {
		games_summary[count] = document.getElementById("summ_game"+(count+1));
	}
	
	//set all to off
	global_summary.className = "summary2";
	for (count = 0; count < numGames; count++) {
		if (games_summary[count] != null) {
		games_summary[count].className = "result";
		}
	}
	//turn on the right one
	if (which == "global") {
		document.getElementById("summ_"+which).className = "summary2_on";
		
		//special case, global has no history, if on history set it to simple
		if (current_type == "history") {
			current_type = "simple";
		}
	}
	else {
		document.getElementById("summ_"+which).className = "result_on";
	}
	
	//set the current type in the new scope
	summary_type(current_type);
}

function summary_type(type) {
	current_type = type;

	var game_simple = document.getElementById(current_scope+"_simple");
	var game_detailed = document.getElementById(current_scope+"_detailed");
	var game_history = document.getElementById(current_scope+"_history");
	
	if (game_simple != null) { game_simple.style.display = "none"; }
	if (game_detailed != null) { game_detailed.style.display = "none"; }
	if (game_history != null) { game_history.style.display = "none"; }
	
	if (document.getElementById(current_scope+"_"+type) != null) {
		document.getElementById(current_scope+"_"+type).style.display = "block";
	}
}


function switch_weapon(which) {
	var simple = document.getElementById("weaponstats_simple");
	var detailed = document.getElementById("weaponstats_detailed");
	if (which == "simple") {
		simple.style.display = "block";
		detailed.style.display = "none";
	}
	else if (which == "detailed") {
		simple.style.display = "none";
		detailed.style.display = "block";
	}
}

//kill matrix hover stuff

function get_sibling_id(id) {
	var regex = /^(\d+):(\d+)$/;
	return id.replace(regex, "$2:$1");
}

function highlight() {
	this.className = "hovered";
	var sibling = document.getElementById( get_sibling_id(this.id) );
	sibling.className = "hovered";
}

function lowlight() {
	this.className = "none";
	var sibling = document.getElementById( get_sibling_id(this.id) );
	sibling.className = "none";
}

function create_matrix_hover() {
	var killmatrix = document.getElementById("killmatrix");
	var currentrow, currentcell;
	var i,j;
	for (i =1; i < killmatrix.rows.length; i++) {
		currentrow = killmatrix.rows[i];
		for (j=1; j < currentrow.cells.length; j++) {
			currentcell = currentrow.cells[j];
			currentcell.id = i + ":" + j;
			currentcell.onmouseover = highlight;
			currentcell.onmouseout = lowlight;
		} 
	}
}